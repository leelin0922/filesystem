# Hardware test data protocal

## Hardware Test

* ajax request json data for test
  ```json
  {
      "categories": "hardware_test", 
      "type": "test"
  }
  ```
* response ajax json data for test
  ```json
  {
      "categories": "hardware_test",
      "type": "test",
      "data": {
          "eeprom":{
              "status":"error"
          }
      },
      "status":"ok"
  }
  ```
